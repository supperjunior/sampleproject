from MultiValueDistionary import MultiValueDictionary


def main(self=None):
    mvd = MultiValueDictionary()
    commands = {
        'keys': lambda args: mvd.keys() if not args else print("Error: This command does not take any arguments"),
        'members': lambda args: mvd.members(args[0]) if len(args) == 1 else print("Error: This command requires exactly one argument"),
        'add': lambda args: mvd.add(args[0], ' '.join(args[1:])) if len(args) >= 2 else print("Error: This command requires at least two arguments"),
        'remove': lambda args: mvd.remove(args[0], ' '.join(args[1:])) if len(args) >= 2 else print("Error: This command requires at least two arguments"),
        'removeall': lambda args: mvd.removeall(args[0]) if len(args) == 1 else print("Error: This command requires exactly one argument"),
        'clear': lambda args: mvd.clear() if not args else print("Error: This command does not take any arguments"),
        'keyexists': lambda args: mvd.keyexists(args[0]) if len(args) == 1 else print("Error: This command requires exactly one argument"),
        'memberexists': lambda args: mvd.memberexists(args[0], ' '.join(args[1:])) if len(args) >= 2 else print("Error: This command requires at least two arguments"),
        'allmembers': lambda args: mvd.allmembers() if not args else print("Error: This command does not take any arguments"),
        'items': lambda args: mvd.items() if not args else print("Error: This command does not take any arguments")
    }

    while True:
        command_input = input("> ").strip().split()
        if not command_input:
            continue
        command = command_input[0].lower()
        args = command_input[1:]

        if command in commands:
            commands[command](args)
        else:
            print("Unknown command. Please try again.")


if __name__ == '__main__':
    main()