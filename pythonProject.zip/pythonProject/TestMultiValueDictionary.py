import unittest
from unittest.mock import patch
from io import StringIO

from MultiValueDistionary import MultiValueDictionary


class TestMultiValueDictionary(unittest.TestCase):
    def setUp(self):
        self.mvd = MultiValueDictionary()

    def test_add_and_members(self):
        self.mvd.add("key1", "value1")
        self.mvd.add("key1", "value2")
        self.mvd.add("key2", "value3")
        self.mvd.add("key3", "value4")
        self.assertEqual(self.mvd.dictionary, {
            "key1": ["value1", "value2"],
            "key2": ["value3"],
            "key3": ["value4"]
        })
        with patch('sys.stdout', new=StringIO()) as fake_out:
            self.mvd.members("key1")
            self.assertEqual(fake_out.getvalue().strip(), "1) value1\n2) value2")

    def test_remove(self):
        self.mvd.add("key1", "value1")
        self.mvd.add("key1", "value2")
        self.mvd.remove("key1", "value1")
        self.assertEqual(self.mvd.dictionary, {"key1": ["value2"]})
        with patch('sys.stdout', new=StringIO()) as fake_out:
            self.mvd.remove("key1", "value1")
            self.assertEqual(fake_out.getvalue().strip(), "ERROR, member does not exist")

    def test_removeall(self):
        self.mvd.add("key1", "value1")
        self.mvd.add("key2", "value2")
        self.mvd.removeall("key1")
        self.assertEqual(self.mvd.dictionary, {"key2": ["value2"]})
        with patch('sys.stdout', new=StringIO()) as fake_out:
            self.mvd.removeall("key1")
            self.assertEqual(fake_out.getvalue().strip(), "ERROR, key does not exist")

    def test_clear(self):
        self.mvd.add("key1", "value1")
        self.mvd.clear()
        self.assertEqual(self.mvd.dictionary, {})
        with patch('sys.stdout', new=StringIO()) as fake_out:
            self.mvd.clear()
            self.assertEqual(fake_out.getvalue().strip(), "Cleared")

    def test_keyexists(self):
        self.mvd.add("key1", "value1")
        self.assertTrue(self.mvd.keyexists("key1"))
        self.assertFalse(self.mvd.keyexists("key2"))

    def test_memberexists(self):
        self.mvd.add("key1", "value1")
        self.assertTrue(self.mvd.memberexists("key1", "value1"))
        self.assertFalse(self.mvd.memberexists("key1", "value2"))
        self.assertFalse(self.mvd.memberexists("key2", "value1"))

    def test_allmembers(self):
        self.mvd.add("key1", "value1")
        self.mvd.add("key1", "value2")
        with patch('sys.stdout', new=StringIO()) as fake_out:
            self.mvd.allmembers()
            self.assertEqual(fake_out.getvalue().strip(), "1) value1\n2) value2")

    def test_items(self):
        self.mvd.add("key1", "value1")
        self.mvd.add("key2", "value2")
        with patch('sys.stdout', new=StringIO()) as fake_out:
            self.mvd.items()
            self.assertEqual(fake_out.getvalue().strip(), "1) key1: value1\n2) key2: value2")

if __name__ == '__main__':
    unittest.main()