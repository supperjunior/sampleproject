class MultiValueDictionary:
    def __init__(self):
        self.dictionary = {}

    def keys(self):
        if self.dictionary:
            for i, key in enumerate(self.dictionary, 1):
                print(f"{i}) {key}")
        else:
            print("(empty set)")

    def members(self, key):
        if key in self.dictionary:
            for i, value in enumerate(self.dictionary[key], 1):
                print(f"{i}) {value}")
        else:
            print("ERROR, key does not exist.")

    def add(self, key, value):
        if key in self.dictionary:
            if value in self.dictionary[key]:
                print("ERROR, member already exists for key")
            else:
                self.dictionary[key].append(value)
                print("Added")
        else:
            self.dictionary[key] = [value]
            print("Added")

    def remove(self, key, value):
        if key in self.dictionary:
            if value in self.dictionary[key]:
                self.dictionary[key].remove(value)
                if not self.dictionary[key]:
                    del self.dictionary[key]
                print("Removed")
            else:
                print("ERROR, member does not exist")
        else:
            print("ERROR, key does not exist")

    def removeall(self, key):
        if key in self.dictionary:
            del self.dictionary[key]
            print("Removed")
        else:
            print("ERROR, key does not exist")

    def clear(self):
        self.dictionary.clear()
        print("Cleared")

    def keyexists(self, key):
        print("true" if key in self.dictionary else "false")
        return key in self.dictionary

    def memberexists(self, key, value):
        print("true" if key in self.dictionary and value in self.dictionary[key] else "false")
        return key in self.dictionary and value in self.dictionary[key]

    def allmembers(self):
        if self.dictionary:
            for key, values in self.dictionary.items():
                for i, value in enumerate(values, 1):
                    print(f"{i}) {value}")
        else:
            print("(empty set)")

    def items(self):
        if self.dictionary:
            for i, (key, values) in enumerate(self.dictionary.items(), 1):
                for value in values:
                    print(f"{i}) {key}: {value}")
        else:
            print("(empty set)")